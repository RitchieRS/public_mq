import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders, HttpParams } from '@angular/common/http';
import { Message } from '../model/message';
//import 'rxjs/add/operator/map' ;
//import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class RequestServerService {

  constructor(private http: HttpClient) { }

  helloWorld() {
        return this.http.get<Message>('http://localhost:3000/test');
  }

  sendMessageService(data: Message){


   console.log(data.message);

    let params = new HttpParams();
    params = params.append('id', data.id);
    params = params.append('autor',data.autor);
    params = params.append('message',data.message);


        return this.http.post<any>('http://localhost:3000/message-receptor', params );
  }
}
