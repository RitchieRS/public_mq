export class Message {
    id: number;
    message: string;
    autor: string;
    constructor(private _id: number, public _message: string, public _autor: string) {
        this.id = _id;
        this.message = _message;
        this.autor = _autor;
    }
}
