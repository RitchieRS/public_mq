import { Component, OnInit } from '@angular/core';
import { RequestServerService } from '../../service/request-server.service';
import { FormControl } from '@angular/forms';
import { Message } from '../../model/message';
@Component({
  selector: 'app-messenger',
  templateUrl: './messenger.component.html',
  styleUrls: ['./messenger.component.css'],
  providers: [ RequestServerService ]
})
export class MessengerComponent implements OnInit {
  autor = new FormControl('');
  message = new FormControl('');
  welcomeMessage = '';
  autorSet=false;
  mlist: string[]  = [];
  constructor(
    private _requestService: RequestServerService
  ) {}

  ngOnInit(): void {}

  setAutor(autor:string) {
      if(autor.length!=0){
        this.autor.setValue('' + autor + '');
        this.autorSet=true;
      }
      else{
        alert("Please type some autor")
      }
  }
  sendMessage(message:string) {
    if(message.length!=0){
        var dataMessage = new Message((this.mlist.length+1),message,this.autor.value);
        this._requestService.sendMessageService(dataMessage).subscribe((res) => {
            this.mlist.push(res.message);
            this.message.setValue('');

        });
    }else{
      alert("Please write any message.")
    }

  }

}
